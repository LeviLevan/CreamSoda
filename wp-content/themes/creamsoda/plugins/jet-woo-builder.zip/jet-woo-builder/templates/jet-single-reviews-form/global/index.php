<?php
/**
 * Reviews template
 */

comments_template();
