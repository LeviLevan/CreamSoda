<?php
/**
 * Categories loop end template
 */
?>
</div>
