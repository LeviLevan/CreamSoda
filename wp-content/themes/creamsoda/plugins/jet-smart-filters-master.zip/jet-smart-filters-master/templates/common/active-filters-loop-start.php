<?php
/**
 * Start active filters loop
 */
?>
<div class="jet-active-filters__list">